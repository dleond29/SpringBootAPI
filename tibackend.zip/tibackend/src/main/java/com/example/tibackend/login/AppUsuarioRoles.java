package com.example.tibackend.login;

public enum AppUsuarioRoles {
    USER,ADMIN
}
