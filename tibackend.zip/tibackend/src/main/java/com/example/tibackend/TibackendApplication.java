package com.example.tibackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TibackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TibackendApplication.class, args);
	}

}
